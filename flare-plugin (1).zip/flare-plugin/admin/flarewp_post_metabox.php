<?php 
/**
 * Flare Core Meta Option
 */
add_action( 'add_meta_boxes', 'flare_custom_meta_boxes', 10, 2 );
function flare_custom_meta_boxes( $post_type, $post ) {
    add_meta_box(
        'flarewp-meta-box',
        __( 'Flare Wp Post OPtions','flarewp'),
        'flarewp_meta_box',
        array('post'), //post types here
        'normal',
        'high'
    );
}


function flarewp_meta_box($post) {
    
 $flare_youtube_video = get_post_meta($post->ID, 'flare_youtube_video', true);
 $flare_footer_text = get_post_meta($post->ID, 'flare_footer_text', true);
 $flare_footer_link = get_post_meta($post->ID, 'flare_footer_link', true);
 $flare_thumbnail_post = get_post_meta($post->ID, 'flare_thumbnail_post', true);
 $flare_video_post = get_post_meta($post->ID, 'flare_video_post', true);
?>
<table>
    <?php
    $youtube_video = '';
    if(!empty($flare_youtube_video)): 
       $youtube_video ='<iframe src="'.esc_url($flare_youtube_video).'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>';
    endif;
    if(!empty($flare_youtube_video)): 
    ?>
    <tr>
      <td><?php echo esc_html__('Youtube Video','flarewp');?></td> 
    </tr>
    <tr>
     <td>
       <!--<label for="flare_youtube_video">
       <?php echo esc_html__('Youtube Video','flarewp');?></label>-->
       <textarea id="flare_youtube_video" name="flare_youtube_video" rows="5" cols="90">
        <?php if(!empty($flare_youtube_video)): ?>
         <?php echo $youtube_video; ?>
        <?php endif; ?>
        </textarea>
      </td>
    </tr>
    <?php endif;
    if(!empty($flare_footer_text) && !empty($flare_footer_link)):
    ?>
    <tr>
    <td>
    <h2><?php echo esc_html__('Add footer link (optional)','flarewp'); ?></h2>
    </td>
    </tr>
    <tr>
    <td> 
    <label for="flare_footer_text"><?php echo esc_html__('Text','flarewp');?></label>
    <input type="text" id="flare_footer_text" name="flare_footer_text" value="<?php echo esc_attr($flare_footer_text); ?>"  style="width:500px;">
    </td>
    <td> 
    <label for="shp_sale_time_title"><?php echo esc_html__('link','shopmartiocore');?></label>
    <input type="text" id="flare_footer_link" name="flare_footer_link" value="<?php echo esc_attr($flare_footer_link); ?>" style="width:500px;">
    </td>
    </tr>
    <?php endif; ?>
</table>
<?php
}

add_action('save_post', 'flarewp_save_postdata'); 
function flarewp_save_postdata($post_id)
{
    if (array_key_exists('flare_youtube_video', $_POST)) {
        update_post_meta(
            $post_id,
            'flare_youtube_video',
            $_POST['flare_youtube_video']
        );
    }
    
    if(array_key_exists('flare_footer_text', $_POST)) {
        update_post_meta(
            $post_id,
            'flare_footer_text',
            $_POST['flare_footer_text']
        );
    }
    
    if(array_key_exists('flare_footer_link', $_POST)) {
        update_post_meta(
            $post_id,
            'flare_footer_link',
            $_POST['flare_footer_link']
        );
    }
}