<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package motov4
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
$motov4_redux = motov4_global_redux();
$sid_cls = $motov4_redux['sidebar_style'];
$side_col = $motov4_redux['sidebar_postion'] == 'both' ? 'col-lg-3 col-md-6' : 'col-md-4';
?>

<div class="<?php echo esc_attr($side_col);?>">
	<div class="<?php echo esc_attr($sid_cls);?>">
		<div class="motov4_sidebar_wrapper">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div><!-- #secondary -->
	</div>	
</div>
