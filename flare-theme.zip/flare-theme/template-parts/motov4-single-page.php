<?php
/*
**
Template Name: Single Page Website
**
*/

	get_header(); 
	$query = $page_ids = '';

	if(function_exists('motov4_sort_sections')):
	$page_ids = motov4_sort_sections();
	endif;
	$args = array(
	   'post_type' => 'Page',
	   'posts_per_page' => -1,
	   'post__in'  => $page_ids,
	   'orderby' => 'post__in',
	 );
	$post = motov4_global_post_var(); 
	$query = new WP_Query($args);
    echo '<div class="motov4_page_content_wrapper">
			<div class="container">
			<div class="row">';      
			if($query->have_posts()):
				while($query->have_posts()): $query->the_post();
					echo '<div class="motov4_single_layout page-section-'.get_post_type().'-';the_ID();  echo '" id="motov4-'.$post->post_name.'">';
                    the_content();
                echo '</div>';
			  endwhile;
			else:
	            get_template_part( 'template-parts/content', 'none');
	        endif;
	echo '</div></div></div>';
get_footer();
?>