<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package motov4
 */

$motov4_local = motov4_local_var();
$post = motov4_global_post_var();

$metas['date']    = true;
$metas['author']  = true;
?>
<div id="post-<?php the_ID(); ?>" <?php post_class('motov4_blog'); ?>>
	<div class="motov4_blog_wrapper">
	<?php $motov4_local->motov4_set_feature_image($post->ID, array('divcls'=>'motov4_blog_image','imgcls'=>''), 'motov4_postimage', array()); ?>
		<div class="motov4_blog_detail">	
			<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="'.esc_attr__('bookmark','motov4').'">', '</a></h3>' );	?>
			<div class="motov4_blog_meta">
				<?php if ( 'post' === get_post_type() ) : $motov4_local->motov4_post_meta($post->ID, $metas); endif; ?>
			</div>
			<div class="entry-content">
				<?php the_excerpt(); ?>
			</div><!-- .entry-content -->
			
			<?php if ( !is_singular() ){ ?>
				<a href="<?php echo esc_url( get_permalink() ); ?>" class="motov4_btn"><?php echo esc_html__("Read More","motov4");?></a>
			<?php } ?>
			
			<footer class="entry-footer">
				<?php motov4_entry_footer(); ?>
			</footer><!-- .entry-footer -->
			
		</div>
	</div>
	
</div><!-- #post-<?php the_ID(); ?> -->
