<?php
/**
** Template Name: Under Construction
**/
get_header();
$motov4_redux = motov4_global_redux();

extract($motov4_redux);
$back = '';
if( $uc_back_type == 'image' ){
	if(empty($uc_back_image['url'])){
		if($uc_style == 'template4'){
			$back = 'background:url('.get_template_directory_uri().'/assets/images/uc_temp4.jpg)';
		}elseif($uc_style == 'template5'){
			$back = 'background:url('.get_template_directory_uri().'/assets/images/uc_temp5.jpg)';
		}
	}else{
		$back = 'background:url('.$uc_back_image['url'].')';
	}
}else{
	$back = 'background:'.esc_attr($uc_back_color).'';
}

$wrp_cls = $uc_style == 'template2' ? ' con_style2' : ($uc_style == 'template3' ? ' con_style3' : ($uc_style == 'template4' ? ' con_style4' : ($uc_style == 'template5' ? ' con_style5' : '')));
function mt4_uc_timer(){
	$motov4_redux = motov4_global_redux();
	extract($motov4_redux);
	$santizedate = array();
	if(!empty($uc_date)){
		$getDate = explode('/',$uc_date);
		$santizedate['day'] = $getDate[1];
		$santizedate['month'] = $getDate[0];
		$santizedate['year'] = $getDate[2];
	}
	
	$santizedate['zone'] = $uc_timezone;
	$targetDate = json_encode($santizedate);
	
	if(!empty($uc_time)){
		if($uc_period != '1' ){
			$time_array = explode(":",$uc_time);
			$uc_time = ($time_array[0] + 12);
			$uc_time .= '/'.$time_array[1];
		}else{
			$time_array = explode(":",$uc_time);
			$uc_time  = $time_array[0];
			$uc_time .= isset($time_array[1]) ? '/'.$time_array[1] : '';
		}
	}
	
	$style_cls = ( $uc_timer_style == 'style2' ? 'motov4_countdown_style1' : ( $uc_timer_style == 'style3' ? 'motov4_countdown_style2' : ( $uc_timer_style == 'style4' ? 'motov4_countdown_style3' : ($uc_timer_style == 'style5' ? 'motov4_countdown_style4' : 'motov4_countdown_style') ) ) );
	$color_cls = $uc_timer_style == 'style5' ? 'style5_countdown' : 'all4_countdown';
	
	echo '<div class="motov4_countdown_wrapper '.esc_attr($style_cls).'">
			<input type="hidden" class="counter_date_time" data-date="'.esc_attr($targetDate).'" data-time="'.esc_attr($uc_time).'">
				<div class="ce-countdown ce-countdown--theme-1">
					<div class="ce-col"><span class="ce-days '.esc_attr($color_cls).'"></span> <span class="ce-days-label countdown_label"></span></div>
					<div class="ce-col"><span class="ce-hours '.esc_attr($color_cls).'"></span> <span class="ce-hours-label countdown_label"></span></div>
					<div class="ce-col"><span class="ce-minutes '.esc_attr($color_cls).'"></span> <span class="ce-minutes-label countdown_label"></span></div>
					<div class="ce-col"><span class="ce-seconds '.esc_attr($color_cls).'"></span> <span class="ce-seconds-label countdown_label"></span></div> 
				</div>
			</div>';
	wp_enqueue_script('motov4-counter');		
}
?>

<div class="mt4_construction_wrapper<?php echo esc_attr($wrp_cls)?>" style="<?php echo esc_attr($back);?>">
	<?php
		if($uc_style == 'template3'){
			echo '<div class="mt4_construction_img">
					<img src="'.get_template_directory_uri().'/assets/images/under-construction3.png" class="img-fluid">
				 </div>';
		}
	?>
	
			<?php
				switch($uc_style){
					case 'template1': ?>
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-6 justify-content-center d-flex">
								<div class="mt4_construction_img">
									<img src="<?php echo get_template_directory_uri().'/assets/images/under-construction2.png';?>" class="img-fluid">
								</div>
							</div>
							<div class="col-lg-5 align-items-center d-flex">
								<div class="mt4_construction_data">
									<?php echo !empty($uc_head) ? '<h1>'.esc_html($uc_head).'</h1>' : ''; ?>
									<?php echo !empty($uc_desc) ? '<p>'.esc_html($uc_desc).'</p>' : ''; ?>
									<?php 
											echo !empty($uc_timer_head) ? '<h3>'.esc_html($uc_timer_head).'</h3>' : '';
											mt4_uc_timer();
										?>
									<div class="subscribe">
										<?php echo !empty($uc_form) ? do_shortcode('[lead_form select_form="'.esc_attr($uc_form).'"]') : ''; ?>
									</div>
									<?php if($uc_social == true) { ?>
									<div class="mt4_uc_social">
										<?php echo motov4_social_icons(); ?>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				<?php
					break;	
					case 'template2': ?>
					<div class="container">
						<div class="row">
							<div class="col-lg-8 align-items-center d-flex offset-lg-2">
								<div class="mt4_construction_data">
									<?php echo !empty($uc_head) ? '<h1>'.esc_html($uc_head).'</h1>' : ''; ?>
									<?php echo !empty($uc_desc) ? '<p>'.esc_html($uc_desc).'</p>' : ''; ?>
									<?php echo !empty($uc_timer_head) ? '<h3>'.esc_html($uc_timer_head).'</h3>' : ''; 
										  mt4_uc_timer();	
									?>
									<div class="subscribe">
										<?php echo !empty($uc_form) ? do_shortcode('[lead_form select_form="'.esc_attr($uc_form).'"]') : ''; ?>
									</div>
									<?php if($uc_social == true) { ?>
									<div class="mt4_uc_social">
										<?php echo motov4_social_icons(); ?>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				<?php
					break;
					case 'template3': ?>
					<div class="container">
						<div class="row">
							<div class="col-lg-6">
								<div class="mt4_construction_data">
									<?php echo !empty($uc_head) ? '<h1>'.esc_html($uc_head).'</h1>' : ''; ?>
									<?php echo !empty($uc_desc) ? '<p>'.esc_html($uc_desc).'</p>' : ''; ?>
									<?php echo !empty($uc_timer_head) ? '<h3>'.esc_html($uc_timer_head).'</h3>' : '';
										  mt4_uc_timer();	
									?>
									<div class="subscribe">
										<?php echo !empty($uc_form) ? do_shortcode('[lead_form select_form="'.esc_attr($uc_form).'"]') : ''; ?>
									</div>
									<?php if($uc_social == true) { ?>
									<div class="mt4_uc_social">
										<?php echo motov4_social_icons(); ?>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				<?php
					break;
					case 'template4': ?>
					<div class="container">
						<div class="row">
							<div class="col-lg-8 offset-lg-2">
								<div class="mt4_construction_data">
									<?php echo !empty($uc_head) ? '<h1>'.esc_html($uc_head).'</h1>' : ''; ?>
									<?php echo !empty($uc_desc) ? '<p>'.esc_html($uc_desc).'</p>' : ''; ?>
									<?php echo !empty($uc_timer_head) ? '<h3>'.esc_html($uc_timer_head).'</h3>' : '';
										 if( $uc_tilmer != '0' ) mt4_uc_timer();	
									?>
									<div class="subscribe">
										<?php echo !empty($uc_form) ? do_shortcode('[lead_form select_form="'.esc_attr($uc_form).'"]') : ''; ?>
									</div>
									<?php if($uc_social == true) { ?>
									<div class="mt4_uc_social">
										<?php echo motov4_social_icons(); ?>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				<?php
					break;
					case 'template5': ?>
					<div class="container">
						<div class="row">
							<div class="col-lg-10 offset-lg-1">
								<div class="mt4_construction_data">
									<?php echo !empty($uc_head) ? '<h1>'.esc_html($uc_head).'</h1>' : ''; ?>
									<?php echo !empty($uc_desc) ? '<p>'.esc_html($uc_desc).'</p>' : ''; ?>
									<?php echo !empty($uc_timer_head) ? '<h3>'.esc_html($uc_timer_head).'</h3>' : '';
										  mt4_uc_timer();	
									?>
									<div class="subscribe">
										<?php echo !empty($uc_form) ? do_shortcode('[lead_form select_form="'.esc_attr($uc_form).'"]') : ''; ?>
									</div>
									<?php if($uc_social == true) { ?>
									<div class="mt4_uc_social">
										<?php echo motov4_social_icons(); ?>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				<?php
					break;
				}
			?>
</div>
<?php get_footer(); ?>