<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package motov4
 */

$motov4_local = motov4_local_var();
$post = motov4_global_post_var();
$motov4_redux = motov4_global_redux();

extract($motov4_redux);
$metas = array();
$metas['date']    = !empty($post_date) && $post_date == true ? 'date' : '';
$metas['author']  = !empty($post_author) && $post_author == true ? 'author' : '';

$metas['cats']    = !empty($post_cats) && $post_cats == true ? 'cats' : '';
$metas['social']  = !empty($social_share) && $social_share == true ? 'social' : '';
$metas['social_style']  = $social_style;
$style = isset($post_style) ? $post_style : '';
?>
<div id="post-<?php the_ID(); ?>" <?php post_class('motov4_blog'); ?>>
<div class="motov4_blog_wrapper">
<?php $motov4_local->motov4_set_feature_image($post->ID, array('divcls'=>'motov4_blog_image','imgcls'=>''), 'motov4_postimage', array()); ?>
	
	<div class="motov4_blog_detail">
	<?php
		if ( is_sticky() && is_home() && ! is_paged() ) {
			printf( '<span class="sticky-post">%s</span>', _x( 'Featured', 'post', 'motov4' ) );
		}
		if(has_post_thumbnail() && $style != 'motov4_single_dark' && $author_img == true){
			$motov4_local->motov4_post_author_image($post->post_author);
		}
		
		//if($style == 'motov4_single_default' || $style == 'motov4_single_dark')
			//the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="'.esc_attr__('bookmark','motov4').'">', '</a></h3>' );
	
		$style == 'motov4_single_dark' && $author_img == true ? $motov4_local->motov4_post_author_image($post->post_author) : '';
		?>
		<?php
			//if($style != 'motov4_single_default' && $style != 'motov4_single_dark'){
				if(is_single()){
					the_title( '<h3 class="entry-title">', '</h3>' );
				}else{
					the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="'.esc_attr__('bookmark','motov4').'">', '</a></h3>' );
				}
			//}
				
		?>
		<div class="motov4_blog_meta">
			<?php if( $style == 'motov4_single_default' ){
					if(is_archive()){
						$metas['date']    = true;
						$metas['author']  = true;
					}
					if ( 'post' === get_post_type() ) : $motov4_local->motov4_post_meta($post->ID, $metas); endif;
			 }else{
				$post_author  = !empty($post_author) && $post_author == false ? false : true;
				$post_date    = !empty($post_date) && $post_date == false ? false : true;
				 $user_info = get_userdata($post->post_author);
				 $fname = !empty($user_info->first_name) ? $user_info->first_name : $user_info->user_login;
				 $lname = $user_info->last_name;
				 $author = get_author_posts_url($post->post_author);
				 echo '<ul>';
				 
				 if($post_author == true){
					 echo '<li class="meta_user_name"><i class="fa fa-user"></i><a href="'.esc_url($author).'">'.esc_html__('By','motov4').' - '.esc_html($fname).' '.esc_html($lname).'</a></li>';
				 }
				 if($post_date == true){
					echo '<li class="meta_date"><i class="fa fa-calendar"></i>'.get_the_date().'</li>';
				 }
				 echo '</ul>';
			 }
			 ?>
		</div>
		<div class="entry-content">
			<?php
			if ( is_front_page() && is_home() ) {
			  the_content();
			} elseif ( is_home() || is_archive() ) {
			  the_excerpt();
			} else{
				the_content( sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers */
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'motov4' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					get_the_title()
				) );
			}
			
			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'motov4' ),
				'after'  => '</div>',
			) );
			?>
		</div><!-- .entry-content -->
		<?php 
		// ------------- Flare code ------------------ //
		$src = get_post_meta(get_the_ID(), 'flare_youtube_video',true);
		$footer_text = get_post_meta(get_the_ID(), 'flare_footer_text',true);
		$footer_link = get_post_meta(get_the_ID(), 'flare_footer_link',true );
		
        if(!empty($src)){
        echo '<iframe title="YouTube video player" src="'.$src.'" frameborder="0" allowfullscreen="allowfullscreen" width= "600px" height= "400px"></iframe>';
        }
        
        //button
        if(!empty($footer_text)){
            echo '<a href="'.esc_url($footer_link).'" target="_blank">'.esc_html($footer_text).'</a>';
        }
        // ------------- Flare code ------------------ //
        
		if(is_archive()){ ?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="motov4_btn"><?php echo esc_html__("Read More","motov4");?></a>
		<?php } ?>
		<footer class="entry-footer">
			<?php motov4_entry_footer(); ?>
		</footer><!-- .entry-footer -->
		<?php $motov4_local->motov4_social_sharing($post->ID); //Get Sharing Buttons  ?>
	</div>
	</div>
	<?php $about_author == true ? $motov4_local->motov4_about_post_author($post->post_author) : ''; ?>
	<?php $realted_post == true ? $motov4_local->motov4_related_post_slider($post->ID) : ''; ?>
		
</div><!-- #post-<?php the_ID(); ?> -->
