<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package motov4
 */

get_header();

$motov4_redux = motov4_global_redux();
extract( $motov4_redux );
$container = isset($container_width) ? $container_width : 'container';
?>
	<div class="<?php echo esc_attr($container);?>">
		<div class="row">
			<?php
				$col = $sidebar_postion == 'full' ? 'col-md-12' : ($sidebar_postion == 'both' ? 'col-md-6' : 'col-md-8 '.$sidebar_postion);
				$col .= $sidebar_postion == 'both' || $sidebar_postion == 'left' ? ' order-lg-2' : '';
			?>
			<div class="<?php echo esc_attr($col); ?>">

				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part( 'template-parts/content', get_post_type() );

					the_post_navigation();

					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				endwhile; // End of the loop.
				?>
			</div>
			<?php
				if($sidebar_postion == 'left' || $sidebar_postion == 'both'): 
					get_sidebar( 'left' );
				endif;
				if($sidebar_postion == 'right' || $sidebar_postion == 'both'): 
					get_sidebar( 'right' );
				endif;
			?>
		</div>
	</div>

<?php get_footer(); ?>