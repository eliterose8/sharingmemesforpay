<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package motov4
 */

get_header();
$motov4_redux = motov4_global_redux();
extract( $motov4_redux );
?>
	<div class="motov4_error_wrapper">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 col-12">
					<div class="blog_error_data">
						<h1><?php esc_html_e('Error','motov4');?></h1>
						<h2><?php esc_html_e('404','motov4');?></h2>
						<h3><?php esc_html_e("Ooops!! page Not Found !","motov4")?></h3>
						<a href="<?php echo esc_url(home_url())?>" class="motov4_btn"><?php esc_html_e('back to home','motov4');?></a>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 col-12">
					<div class="blog_error_img">
						<img src="<?php echo get_template_directory_uri() . '/assets/images/error_img.png';?>" class="img-fluid" alt="<?php esc_attr__('motov4_404','motov4');?>">
					</div>
				</div>
			</div>
		</div>
	</div>

<?php get_footer(); ?>
