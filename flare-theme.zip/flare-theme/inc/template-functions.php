<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package motov4
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function motov4_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}
	
	global $motov4_redux;
	if(is_archive() || is_home() || is_search()){
		$classes[] = !empty($motov4_redux['default_post_style']) ? $motov4_redux['default_post_style'] . ' motov4_blog_single' : 'motov4_single_default';
		if(class_exists( 'WooCommerce' ) && is_shop()){
			$classes[] = !empty($motov4_redux['woo_style']) ? $motov4_redux['woo_style'] : 'woo_default';
		}
	}elseif(is_single()){
		$classes[] = !empty($motov4_redux['post_style']) ? $motov4_redux['post_style'] . ' motov4_blog_single' : 'motov4_single_default';
		if(class_exists( 'WooCommerce' )){
			$classes[] = !empty($motov4_redux['woo_style']) ? $motov4_redux['woo_style'] : 'woo_default';
		}
	}elseif(class_exists( 'WooCommerce' ) && (is_cart() || is_checkout())){
		$classes[] = !empty($motov4_redux['woo_style']) ? $motov4_redux['woo_style'] : 'woo_default';
	}else{
		$classes[] = !empty($motov4_redux['motov4_post_style']) ? $motov4_redux['motov4_post_style'] . ' motov4_blog_single' : 'motov4_single_default';
	}
	
	if(is_home() || is_single() || is_archive() || is_search() || (function_exists('is_shop') && is_shop()))
	$classes[] = isset($motov4_redux['page_title_switch']) && $motov4_redux['page_title_switch'] != 1 ? 'noPageTitle' : '';
		
	$classes[] = $motov4_redux['header_fix'] == 1 ? 'motov4_fixed_header' : '';
	$classes[] = $motov4_redux['boxed_layout'] == 1 ? 'motov4_boxed' : '';
	$classes[] = has_nav_menu( 'motov4_mega_menu' ) ? 'motov4_mega_menu' : '';

	return $classes;
}
add_filter( 'body_class', 'motov4_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function motov4_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'motov4_pingback_header' );
