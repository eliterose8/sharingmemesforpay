<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package motov4
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
$motov4_local = motov4_local_var();
?>

<div class="motov4_comment_wrapper">

	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) :
		?>
		<h3 class="motov4_comment_title">
			<?php
			$motov4_comment_count = get_comments_number();
			echo 'Comments (',$motov4_comment_count,')';
			?>
		</h3><!-- .comments-title -->

		<?php the_comments_navigation(); ?>
			<div class="motov4_comment_list">
				<ol class="comment-list">
					<?php
					wp_list_comments( array(
						'style'      => 'ol',
						'avatar_size'=> 100,
						'callback'   => array($motov4_local, 'motov4_comments_list'),
						'short_ping' => true,
					) );
					?>
				</ol><!-- .comment-list -->
			</div>

		<?php
		the_comments_navigation();

		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'motov4' ); ?></p>
			<?php
		endif;

	endif; // Check for have_comments().
	$args = array(
		'comment_field' => '<p class="comment-form-comment">
							<textarea id="comment" name="comment" cols="45" rows="8" aria-required="true" placeholder="' . _x( 'Enter Message', 'Enter Message', 'motov4' ) . '"></textarea></p>',
		'comment_notes_before' => '',					
		'fields' => apply_filters( 'comment_form_default_fields', array(
			  'author' =>
				'<p class="comment-form-author">
				<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
				'" size="30" placeholder="'.__( 'Enter Name', 'motov4' ).'"/></p>',

			  'email' =>
				'<p class="comment-form-email">
				<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
				'" size="30" placeholder="'.__( 'Enter Email', 'motov4' ).'"/></p>',

			  'url' =>
				'<p class="comment-form-url">
				<input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) .
				'" size="30" placeholder="'.__( 'Enter Website', 'motov4' ).'"/></p>',
				
				'cookies'	=> ''
			)
		),
		
	);
	comment_form($args);
	?>

</div><!-- #comments -->
