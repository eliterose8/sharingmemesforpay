<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ultra_Suite
 */

// if ( ! is_active_sidebar( 'sidebar-2' ) ) {
	// return;
// }

$motov4_redux = motov4_global_redux();
$sid_cls = $motov4_redux['sidebar_style'];
$pos = $motov4_redux['sidebar_postion'];
$side_col = $pos == 'both' ? 'col-lg-3 col-md-6' : 'col-md-4';
$side_col .= $pos == 'both' || $pos == 'left' ? ' order-lg-1' : '';
?>

<?php
if (function_exists('wc_get_page_id') && (wc_get_page_id( 'cart' ) == get_the_ID() || wc_get_page_id( 'checkout' ) == get_the_ID()) ) {  ?>
	<div class="col-lg-3 col-md-6">
		<div class="<?php echo esc_attr($sid_cls);?>">
			<div class="motov4_sidebar_wrapper">
				<?php dynamic_sidebar( 'motov4-woo' ); ?>
			</div><!-- #secondary -->
		</div>	
	</div>
<?php 
}else{
	
?>
<div class="<?php echo esc_attr($side_col);?>">
	<div class="<?php echo esc_attr($sid_cls);?>">
		<div class="motov4_sidebar_wrapper">
			<?php dynamic_sidebar( 'sidebar-2' ); ?>
		</div><!-- #secondary -->
	</div>	
</div>
<?php } ?>
