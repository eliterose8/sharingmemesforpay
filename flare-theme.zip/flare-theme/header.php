<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package motov4
 */

$motov4_local = motov4_local_var();
global $motov4_redux,$motov4_options;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	
	<?php wp_head(); 
	
	echo $motov4_options['analytics_script_header'];
	?>
</head>
<body <?php body_class(); ?>>
	<?php 
	echo $motov4_options['analytics_script_body'];
	?>
	<!-- Boxed Layout -->
	<?php echo (isset($motov4_redux['boxed_layout']) && $motov4_redux['boxed_layout'] == 1) ? '<div class="motov4_boxed_wrapper">' : ''; ?>

	<!-- preloader start -->
	<?php //$motov4_local->motov4_site_loader(); ?>
	<!-- preloader end -->
	
	<!-- search box start -->
	<?php require get_template_directory() . '/vendor/partials/search.php'; ?>
	<!-- search box end -->
	
	<div class="motov4_main_wrapper">
		<?php
		if( !is_page_template('template-parts/motov4-underconstruction.php') ){
			$meta_values = function_exists('redux_post_meta') ? redux_post_meta( 'motov4_options', get_the_id() ) : array();
			//**header start**//
			if(isset($meta_values['motov4_override_header']) && $meta_values['motov4_override_header'] == "1"){
				$meta_values['motov4_header_switch'] == "1" ? require get_template_directory() . '/vendor/header/header.php' : '';
			}else{
				require get_template_directory() . '/vendor/header/header.php';
			}
			//**header end**//
			
			//**page title start**//
			require get_template_directory() . '/vendor/partials/page_title.php';
			//**page title end**//
		}
		?>
		<div class="motov4_page_content_wrapper <?php echo esc_attr($motov4_redux['sidebar_style']);?>">