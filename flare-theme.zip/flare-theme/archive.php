<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package motov4
 */

get_header();
$motov4_redux = motov4_global_redux();
extract( $motov4_redux );
$container = isset($container_width) ? $container_width : 'container';
?>
	<div class="<?php echo esc_attr($container);?>">
		<div class="row">
			<?php
				$col = $sidebar_postion == 'full' ? 'col-md-12' : ($sidebar_postion == 'both' ? 'col-md-6' : 'col-md-8 '.$sidebar_postion);
				$col .= $sidebar_postion == 'both' || $sidebar_postion == 'left' ? ' order-lg-2' : '';
			?>
			<div class="<?php echo esc_attr($col); ?>">
				<?php if ( have_posts() ) : ?>
				
					<div class="motov4_blog_list">
						<?php
						/* Start the Loop */
						while ( have_posts() ) :
							the_post();

							/*
							 * Include the Post-Type-specific template for the content.
							 * If you want to override this in a child theme, then include a file
							 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
							 */
							get_template_part( 'template-parts/content', get_post_type() );

						endwhile;
						?>
					</div>
					<?php the_posts_navigation(); ?>

				<?php else : ?>

					<?php get_template_part( 'template-parts/content', 'none' ); ?>

				<?php endif; ?>
			</div>
			<?php
				if($sidebar_postion == 'left' || $sidebar_postion == 'both'): 
					get_sidebar( 'left' );
				endif;
				if($sidebar_postion == 'right' || $sidebar_postion == 'both'): 
					get_sidebar( 'right' );
				endif;
			?>
		</div>
	</div>

<?php get_footer(); ?>