<?php
/**
 * MOTO V4 functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package motov4
 */

if ( ! function_exists( 'motov4_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function motov4_setup() {
		
		load_theme_textdomain( 'motov4', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'motov4_primary' => __( 'Primary Menu', 'motov4' ),
			'motov4_mega_menu' => __( 'Mega Menu, For full documentation on this, visit: <a href="#" target="_blank">#Link Here</a>', 'motov4' ),
			'motov4_left_menu' => __( 'Left Menu', 'motov4' ),
			'motov4_right_menu' => __( 'Right Menu', 'motov4' )
		) );
		
		

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'motov4_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
		
		
		add_image_size( 'service_overlay_img', 350, 234, true );
		add_image_size( 'motov4_team_img', 378, 452, true );
		add_image_size( 'motov4_testi_9', 98, 128, true );
		add_image_size( 'motov4_event_img', 570, 357, true );
		add_image_size( 'motov4_portfolio_img', 570, 570, true ); // It will only work for Grid layout.
		
		//Portfolio Masonory Image Size
		add_image_size( 'motov4_portfolio_mas_img1', 370, 410, true );
		add_image_size( 'motov4_portfolio_mas_img2', 370, 250, true );
		
		//Blog Posts
		add_image_size( 'motov4_post_570_370', 570, 370, true );
		add_image_size( 'motov4_post_384_500', 384, 500, true );
	}
endif;
add_action( 'after_setup_theme', 'motov4_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function motov4_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'motov4_content_width', 640 );
}
add_action( 'after_setup_theme', 'motov4_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */	
function motov4_widgets_init(){
	register_sidebar( array(
		'name'          => esc_html__( 'Right Sidebar', 'motov4' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'motov4' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</span></h2>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Left Sidebar', 'motov4' ),
		'id'            => 'sidebar-2',
		'description'   => esc_html__( 'Add widgets here.', 'motov4' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</span></h2>',
	) );
	register_sidebar( array(
		'name'          => esc_html__( 'Additional Sidebar', 'motov4' ),
		'id'            => 'sidebar-3',
		'description'   => esc_html__( 'You can add this sidebar to any page using page builder.', 'motov4' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title"><span>',
		'after_title'   => '</span></h2>',
	) );
}
add_action( 'widgets_init', 'motov4_widgets_init' );

/**
 * Registers an editor stylesheet for the theme.
 */
function motov4_add_editor_styles() {
    add_editor_style( 'editor-style.css' );
}
add_action( 'admin_init', 'motov4_add_editor_styles' );


/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Set a constant that holds the theme's minimum supported PHP version.
 */
define( 'MOTOV4_MIN_PHP_VERSION', '5.6' );

require_once get_template_directory() . '/vendor/tgmpa/recommended-plugins.php';

require_once get_template_directory() . '/vendor/motov4-class.php';

require_once get_template_directory() . '/vendor/motov4-functions.php';

require_once get_template_directory() . '/vendor/motov4-mega-menu.php';