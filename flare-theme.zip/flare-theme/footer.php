<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package motov4
 */
?>
</div> <!-- motov4_page_content_wrapper Div End-->
<?php
$motov4_redux = motov4_global_redux();
$motov4_options = motov4_global_options();
extract( $motov4_redux );
/**
 * footer start
*/
$meta_values = function_exists('redux_post_meta') ? redux_post_meta( 'motov4_options', get_the_id() ) : array();
if( !is_page_template('template-parts/motov4-underconstruction.php') ){
	if(isset($meta_values['motov4_override_footer']) && $meta_values['motov4_override_footer'] == "1"){
		$meta_values['motov4_footer_switch'] == "1" ? require get_template_directory() . '/vendor/footer/footer.php' : '';
	}else{
		if($footer_switch){
			require get_template_directory() . '/vendor/footer/footer.php';
		}
	}
}
?>
</div>

<?php if( $backtotop == true ){
$extra_cls = $bakToTop_align == 'left' ? 'motov4_gotop_left' : ($bakToTop_align == 'center' ? 'motov4_gotop_center' : '');
$extra_cls .= !empty($backtotop_custom) ? ' motov4_gotop_custom_img' : '';
?>
<!--Go to top start-->
<div class="motov4_gotop <?php echo esc_attr($extra_cls);?>">
	<div class="motov4_go_top">
	<?php
		if(!empty($backtotop_custom)){
			echo '<img src="'.esc_url($backtotop_custom).'" />';
		}else{
			echo '<svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 349.629 349.629"><polygon points="174.827,73.433 0,253.42 23.434,276.19 174.827,120.318 326.216,276.196 349.629,253.42   " data-original="#000000" class="active-path" data-old_color="#ffffff" fill="#ffffff"/></svg>';
		}
	?>  
	</div>  
</div>
<?php } ?>

<?php echo ($boxed_layout == 1) ? '</div>' : ''; ?>
<?php
echo $motov4_options['analytics_script_footer'];
wp_footer(); ?>
</body>
</html>
