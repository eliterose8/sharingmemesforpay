<?php
/**
 * Plugin Name: Flare Wp Post Plugin
 * Plugin URI:  flarewp
 * Description: Flare Post Content Mange WordPress Plugin.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Flare 
 * Author URI:        https://flaresoft.org/
 * License:           GPL v2 or later
 * License URI:       https://flaresoft.org/
 * Text Domain:       flare
 * Domain Path:       /languages
 */ 
global $flare_plug_version;


$flare_plug_version = '1.0.0';

define('PLUGIN_PATH', plugin_dir_url( __FILE__ ) ); 
define('DANCE_AJAX_URL', admin_url('admin-ajax.php') );
define('PLUGIN_PATH_DIR', plugin_dir_path( __FILE__ ) );
define( 'ELEMENTOR_FENWOODFARM', __FILE__ );
remove_action( 'wp_head', 'rest_output_link_wp_head'); 

/**
 * Elementor Tab in add Widget
 */ 
if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

/**
 * Flare Admin Enqueue 
 */
add_action('admin_enqueue_scripts','flare_adminload_script'); 
function flare_adminload_script(){
    
    wp_enqueue_style('flare-admin-custom-style', PLUGIN_PATH.'assets/css/backend/flare-admin-custom-style.css', array(), '1', 'all');
    wp_enqueue_script('flare-forent-custom-script', PLUGIN_PATH .'assets/js/backend/flare-admin-custom-script.js', array('jquery'),'34535435', true); 
    wp_localize_script('flare-forent-custom-script', 'ajaxobject', array(
     'ajaxurl' => admin_url('admin-ajax.php'),
    ));
}
/**
 * Flar Content Mange
 */
function json_basic_auth_handler($user)
{
    global $wp_json_basic_auth_error;

    $wp_json_basic_auth_error = null;

    // Don't authenticate twice
    if (!empty($user)) {
        return $user;
    }


    // Alternative way
    if (!isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['HTTP_AUTHORIZATION2'])) {
        list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) = explode(':', base64_decode($_SERVER['HTTP_AUTHORIZATION2']));
    }

    // Check that we're trying to authenticate
    if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) {
        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];
    } else {
        return $user;
    }

    $username = $_SERVER['PHP_AUTH_USER'];
    $password = $_SERVER['PHP_AUTH_PW'];

    /**
     * In multi-site, wp_authenticate_spam_check filter is run on authentication. This filter calls
     * get_currentuserinfo which in turn calls the determine_current_user filter. This leads to infinite
     * recursion and a stack overflow unless the current function is removed from the determine_current_user
     * filter during authentication.
     */
    remove_filter('determine_current_user', 'json_basic_auth_handler', 20);

    $user = wp_authenticate($username, $password);

    add_filter('determine_current_user', 'json_basic_auth_handler', 20);

    if (is_wp_error($user)) {
        $wp_json_basic_auth_error = $user;
        return null;
    }

    $wp_json_basic_auth_error = true;

    return $user->ID;
}

add_filter('determine_current_user', 'json_basic_auth_handler', 20);

function json_basic_auth_error($error)
{
    // Passthrough other errors
    if (!empty($error)) {
        return $error;
    }

    global $wp_json_basic_auth_error;

    return $wp_json_basic_auth_error;
}

add_filter('rest_authentication_errors', 'json_basic_auth_error');



if (! class_exists('FlareYoutubeData')) {
    include_once(plugin_dir_path(__FILE__) . 'includes/YoutubeData.php');
}

if (! class_exists('WordPressData')) {
    include_once(plugin_dir_path(__FILE__) . 'includes/WordPressData.php');
}

add_action('rest_api_init', function () {
    register_rest_route('api/v1', '/youtube_video_captions_list/', array(
        'methods' => 'GET',
        'callback' => 'flare_get_video_captions_list',
    ));

    register_rest_route('api/v1', '/youtube_video_caption/', array(
        'methods' => 'GET',
        'callback' => 'flare_get_video_caption',
    ));

    register_rest_route('api/v1', '/create_post/', array(
        'methods' => 'POST',
        'callback' => 'flare_create_post',
    ));
}); 
 
function flare_get_video_captions_list($request)
{
    $youtube_data = new FlareYoutubeData(__FILE__);
    $video_id = $request->get_param('video_id');
    return $youtube_data->getCaptions($video_id);
}

function flare_get_video_caption($request)
{
    $youtube_data = new FlareYoutubeData(__FILE__);
    $video_id = $request->get_param('video_id');
    $lang = strtolower($request->get_param('lang'));
    return $youtube_data->getCaption($video_id, $lang);
}

function flare_create_post($request)
{
    $wordpress = new WordPressData(__FILE__);
    $title = $request->get_param('title');
    $status = $request->get_param('status');
    $date = $request->get_param('date');
    $tags = $request->get_param('tags');
    $categories = $request->get_param('categories');
    $interval_hours = $request->get_param('interval_hours');
    $interval_minutes = $request->get_param('interval_minutes');
    $image_url = $request->get_param('image_url');
    $content = $request->get_param('content');
    $video_url = $request->get_param('video_url');
    $author_id = $request->get_param('author_id');
    $footer_text = $request->get_param('footer_text');
    $footer_link = $request->get_param('footer_link');
    $thumbnail_post = $request->get_param('thumbnail_post');
    $video_post = $request->get_param('video_post');
    
    return $wordpress->createPost($title, $status, $date, $tags, $categories, $interval_hours, $interval_minutes, $image_url, $content, $video_url, $author_id,$footer_text,$footer_link,$thumbnail_post,$video_post);
}